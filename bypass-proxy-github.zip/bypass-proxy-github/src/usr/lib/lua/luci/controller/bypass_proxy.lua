module("luci.controller.bypass_proxy", package.seeall)

function index()
    if not nixio.fs.access("/etc/config/bypass_proxy") then
        return
    end

    local e = entry(
        {"admin", "services", "bypass_proxy"},
        cbi("bypass_proxy"),
        _("Bypass Proxy"),
        60
    )

    e.dependent = false
end
