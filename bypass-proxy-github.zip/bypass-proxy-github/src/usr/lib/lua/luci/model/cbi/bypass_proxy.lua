local sys = require "luci.sys"
local util = require "luci.util"

local INIT = "/etc/init.d/bypass-proxy"

local m = Map(
    "bypass_proxy",
    translate("Bypass Proxy"),
    translate(
        "Selective TCP proxy. Only configured IPv4 destinations " ..
        "are sent through the SOCKS proxy."
    )
)

local s = m:section(
    NamedSection,
    "main",
    "proxy",
    translate("Bypass Proxy")
)

s.anonymous = true
s.addremove = false

-- ============================================================
-- SERVICE HELPERS
-- ============================================================

local function running()
    local result = sys.exec(
        "ubus call service list '{\"name\":\"bypass-proxy\"}' " ..
        "2>/dev/null | " ..
        "jsonfilter -e '@[\"bypass-proxy\"].instances.main.running' " ..
        "2>/dev/null"
    )

    return util.trim(result or "") == "true"
end

local function boot_enabled()
    return sys.call(
        INIT .. " enabled >/dev/null 2>&1"
    ) == 0
end

local function service_action(action)
    sys.call(
        INIT .. " " .. action .. " >/dev/null 2>&1"
    )
end

-- IPv4 / IPv4 CIDR validation (same rules as the init script)
local function ipv4(str)
    local a, b, c, d = str:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")

    if not a then
        return false
    end

    for _, oct in ipairs({ a, b, c, d }) do
        if #oct > 3 or tonumber(oct) > 255 or
           (#oct > 1 and oct:sub(1, 1) == "0") then
            return false
        end
    end

    return true
end

local function destination_ok(str)
    local ip, prefix = str:match("^([%d%.]+)/(%d+)$")

    if ip then
        return ipv4(ip) and
               #prefix <= 2 and
               prefix:sub(1, 1) ~= "0" and
               tonumber(prefix) <= 32
    end

    return ipv4(str)
end

-- ============================================================
-- STATUS
-- ============================================================

local status = s:option(
    DummyValue,
    "_status",
    translate("Status")
)

function status.cfgvalue()
    if running() then
        return translate("Running")
    end

    return translate("Stopped")
end

-- ============================================================
-- START / STOP
-- ============================================================

local toggle = s:option(
    Button,
    "_toggle",
    translate("Service")
)

function toggle.render(self, section, scope)
    if running() then
        self.inputtitle = translate("Stop")
        self.inputstyle = "reset"
    else
        self.inputtitle = translate("Start")
        self.inputstyle = "apply"
    end

    return Button.render(self, section, scope)
end

function toggle.write()
    if running() then
        service_action("stop")
    else
        service_action("start")
    end

    luci.http.redirect(
        luci.dispatcher.build_url(
            "admin",
            "services",
            "bypass_proxy"
        )
    )
end

-- ============================================================
-- RESTART
-- ============================================================

local restart = s:option(
    Button,
    "_restart",
    translate("Restart")
)

restart.inputtitle = translate("Restart")
restart.inputstyle = "reload"

function restart.write()
    service_action("restart")

    luci.http.redirect(
        luci.dispatcher.build_url(
            "admin",
            "services",
            "bypass_proxy"
        )
    )
end

-- ============================================================
-- BOOT
-- ============================================================

local boot = s:option(
    Flag,
    "_boot",
    translate("Start at boot")
)

boot.rmempty = false
boot.enabled = "1"
boot.disabled = "0"

function boot.cfgvalue()
    return boot_enabled() and "1" or "0"
end

function boot.write(self, section, value)
    if value == "1" then
        sys.call(INIT .. " enable >/dev/null 2>&1")
    else
        sys.call(INIT .. " disable >/dev/null 2>&1")
    end
end

-- ============================================================
-- PROXY SERVER
-- ============================================================

local server = s:option(
    Value,
    "server",
    translate("Proxy Server")
)

server.datatype = "host"
server.rmempty = false
server.placeholder = "proxy.example.com"

-- ============================================================
-- PROXY PORT
-- ============================================================

local port = s:option(
    Value,
    "port",
    translate("Proxy Port")
)

port.datatype = "port"
port.rmempty = false
port.placeholder = "1080"

-- ============================================================
-- PROXY TYPE
-- ============================================================

local proxy_type = s:option(
    ListValue,
    "type",
    translate("Proxy Type")
)

proxy_type:value("socks5", "SOCKS5")
proxy_type:value("socks4", "SOCKS4")

proxy_type.default = "socks5"
proxy_type.rmempty = false

proxy_type.description = translate(
    "SOCKS5 supports username/password authentication. " ..
    "SOCKS4 does not support password authentication."
)

-- ============================================================
-- USERNAME
-- ============================================================

local username = s:option(
    Value,
    "username",
    translate("Username")
)

username.rmempty = true
username.maxlength = 255
username.placeholder = translate("Optional")

-- ============================================================
-- PASSWORD
-- ============================================================

local password = s:option(
    Value,
    "password",
    translate("Password")
)

password.password = true
password.rmempty = true
password.maxlength = 255
password.placeholder = translate("Optional")

-- ============================================================
-- LOCAL REDIRECT PORT
-- ============================================================

local local_port = s:option(
    DummyValue,
    "local_port",
    translate("Local Redirect Port")
)

function local_port.cfgvalue(self, section)
    return self.map:get(section, "local_port") or "1337"
end

local_port.description = translate(
    "Internal Redsocks redirect port."
)

-- ============================================================
-- DESTINATIONS
-- ============================================================

local destinations = s:option(
    DynamicList,
    "destination",
    translate("Proxy Destinations")
)

destinations.rmempty = false
destinations.placeholder = "203.0.113.5 or 198.51.100.0/24"

destinations.description = translate(
    "Only TCP connections to these IPv4 addresses or CIDR " ..
    "networks are redirected through the proxy."
)

function destinations.validate(self, value, section)
    local list = type(value) == "table" and value or { value }

    for _, v in ipairs(list) do
        if v and #v > 0 and not destination_ok(v) then
            return nil, translate("Invalid IPv4 address or CIDR network: ") .. v
        end
    end

    return value
end

return m
