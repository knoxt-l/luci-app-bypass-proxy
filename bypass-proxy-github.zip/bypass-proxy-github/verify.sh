#!/bin/sh
# Bypass Proxy verification - run on the router as root (needs a configured proxy).
#   sh bypass-proxy-verify.sh          read-only checks of the running setup
#   sh bypass-proxy-verify.sh --full   also: credential matrix + stop/start lifecycle
#                                      (restarts the service several times, restores your config)

INIT=/etc/init.d/bypass-proxy
CONF=/etc/redsocks-bypass.conf
CHAIN=BYPASS_PROXY
LAN_IF=br-lan
BAK=/tmp/bypass_proxy.verify.bak
PASS=0
FAIL=0

ipt()  { iptables -w "$@"; }
ok()   { echo "PASS  $1"; PASS=$((PASS + 1)); }
bad()  { echo "FAIL  $1"; FAIL=$((FAIL + 1)); }
t()    { d="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$d"; else bad "$d"; fi; }  # must succeed
n()    { d="$1"; shift; if "$@" >/dev/null 2>&1; then bad "$d"; else ok "$d"; fi; }  # must fail

is_running() {
	ubus call service list '{"name":"bypass-proxy"}' 2>/dev/null \
		| jsonfilter -e '@["bypass-proxy"].instances.main.running' 2>/dev/null | grep -qx true
}
mod_loaded() { lsmod | grep -q "^$1 "; }
listening()  { netstat -lnt 2>/dev/null | grep -q "0\.0\.0\.0:$LP "; }
has_line()   { grep -qF -- "$1" "$CONF"; }
has_key()    { grep -qE "^[[:space:]]*$1[[:space:]]*=" "$CONF"; }
perm600()    { [ "$(stat -c %a "$CONF" 2>/dev/null)" = 600 ]; }
chain_gone() { ! ipt -t nat -S "$CHAIN"; }
hook_gone()  { ! ipt -t nat -C PREROUTING -i "$LAN_IF" -p tcp -j "$CHAIN"; }
no_rule()    { ! ipt -t nat -S "$CHAIN" | grep -q -- "$1"; }

LP="$(uci -q get bypass_proxy.main.local_port)"; LP="${LP:-1337}"

echo "== 1. Service status"
t "procd instance running" is_running
t "init script 'status'" $INIT status

echo "== 2. Redsocks configuration syntax"
t "redsocks -t -c $CONF" redsocks -t -c "$CONF"
t "$CONF permissions are 600" perm600

echo "== 3. Kernel modules"
for m in nf_nat iptable_nat xt_REDIRECT; do t "module $m loaded" mod_loaded "$m"; done

echo "== 4/5. Chain and PREROUTING hook"
t "chain $CHAIN exists" ipt -t nat -S "$CHAIN"
t "PREROUTING -i $LAN_IF -p tcp -j $CHAIN" ipt -t nat -C PREROUTING -i "$LAN_IF" -p tcp -j "$CHAIN"
t "redsocks listening on 0.0.0.0:$LP" listening

echo "== 6. REDIRECT rules (one per configured destination)"
DESTS="$(uci -q get bypass_proxy.main.destination)"
for d in $DESTS; do
	t "REDIRECT $d -> :$LP" ipt -t nat -C "$CHAIN" -p tcp -d "$d" -j REDIRECT --to-ports "$LP"
done
ND="$(set -- $DESTS; echo $#)"
NR="$(ipt -t nat -S "$CHAIN" 2>/dev/null | grep -c "^-A $CHAIN ")"
[ "$NR" = "$ND" ] && ok "rule count ($NR) equals destination count ($ND)" || bad "rule count $NR != destination count $ND"
no_rule "0.0.0.0/0"     && ok "no catch-all rule" || bad "catch-all rule present"
n "no UDP redirect rule" sh -c "iptables -w -t nat -S $CHAIN | grep -q -- '-p udp'"

echo "== 7/8. Credentials: UCI vs generated Redsocks config"
echo "UCI username  : '$(uci -q get bypass_proxy.main.username)'"
[ -n "$(uci -q get bypass_proxy.main.password)" ] && echo "UCI password  : <set>" || echo "UCI password  : <empty>"
echo "conf login    : $(grep -E '^[[:space:]]*login[[:space:]]*=' "$CONF" || echo '<absent>')"
has_key password && echo "conf password : <present>" || echo "conf password : <absent>"

# ----------------------------------------------------------------- --full
if [ "$1" = "--full" ]; then
	umask 077
	cp /etc/config/bypass_proxy "$BAK" || exit 1
	WAS=0; is_running && WAS=1
	restore() {
		cp "$BAK" /etc/config/bypass_proxy; rm -f "$BAK"
		if [ "$WAS" = 1 ]; then $INIT restart >/dev/null 2>&1; else $INIT stop >/dev/null 2>&1; fi
	}
	trap 'restore; exit 1' INT TERM

	apply() { uci commit bypass_proxy; $INIT restart >/dev/null 2>&1; }
	reset_creds() { uci -q delete bypass_proxy.main.username; uci -q delete bypass_proxy.main.password; uci set bypass_proxy.main.type=socks5; }

	echo "== 9. Credential matrix (type socks5)"
	reset_creds; apply
	n "1) empty/empty: no login"            has_key login
	n "1) empty/empty: no password"         has_key password

	uci set bypass_proxy.main.username='user1'; apply
	t "2) username only: login written"     has_line 'login = "user1";'
	n "2) username only: no password"       has_key password

	uci set bypass_proxy.main.password='pass1'; apply
	t "3) add password: username kept"      has_line 'login = "user1";'
	t "3) add password: password written"   has_line 'password = "pass1";'

	uci delete bypass_proxy.main.username; apply
	n "4) remove username: no login"        has_key login
	t "4) remove username: password kept"   has_line 'password = "pass1";'

	uci set bypass_proxy.main.username='us"er\1'; uci set bypass_proxy.main.password='pa"ss\2'; apply
	t "5) escaping: login"                  has_line 'login = "us\"er\\1";'
	t "5) escaping: password"               has_line 'password = "pa\"ss\\2";'
	t "5) config still valid + 600"         sh -c "redsocks -t -c $CONF && [ \"\$(stat -c %a $CONF)\" = 600 ]"

	echo "== 10. Lifecycle (stop removes everything, start restores it)"
	cp "$BAK" /etc/config/bypass_proxy; uci -q revert bypass_proxy
	$INIT stop >/dev/null 2>&1
	t "stop: chain removed"                 chain_gone
	t "stop: PREROUTING hook removed"       hook_gone
	n "stop: redsocks not running"          is_running
	$INIT start >/dev/null 2>&1
	t "start: redsocks running"             is_running
	t "start: PREROUTING hook present"      ipt -t nat -C PREROUTING -i "$LAN_IF" -p tcp -j "$CHAIN"
	for d in $DESTS; do t "start: REDIRECT $d" ipt -t nat -C "$CHAIN" -p tcp -d "$d" -j REDIRECT --to-ports "$LP"; done
	$INIT restart >/dev/null 2>&1
	t "restart: running again"              is_running
	t "boot: enabled (S99 symlink)"         $INIT enabled

	restore; trap - INT TERM
fi

echo
echo "Result: $PASS passed, $FAIL failed"
echo "Reboot test: reboot, then run this script again - everything above must still pass."
echo "Client test: from a LAN host run  nc -vz <destination-ip> <port>  and then on the router"
echo "  iptables -t nat -L $CHAIN -n -v -x   (matching rule's pkts counter increases)"
echo "  Connecting to any host NOT in your destination list must NOT increase any counter."
[ "$FAIL" -eq 0 ]
